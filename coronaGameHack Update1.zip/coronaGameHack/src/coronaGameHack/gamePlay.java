package coronaGameHack;

public class gamePlay {

	public gamePlay() {
		// TODO Auto-generated constructor stub
	}

}
