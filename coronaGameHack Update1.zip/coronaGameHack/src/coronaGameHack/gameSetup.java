package coronaGameHack;

public class gameSetup {

	public gameSetup() {
		// TODO Auto-generated constructor stub
	}

}
