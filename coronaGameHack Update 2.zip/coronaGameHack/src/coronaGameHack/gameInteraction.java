package coronaGameHack;

//imports
import acm.graphics.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.*;

import acm.io.*;
import acm.program.*;
import java.lang.*;
import javax.swing.*;

public class gameInteraction extends GraphicsProgram{

	public gameInteraction() {
		// TODO Auto-generated constructor stub
	}

}
