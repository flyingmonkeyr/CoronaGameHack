package coronaGameHack;

//imports
import acm.graphics.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.*;

import acm.io.*;
import acm.program.*;
import java.lang.*;
import javax.swing.*;

public class Main extends GraphicsProgram{

	public Main() {
		// TODO Auto-generated constructor stub
	}
	
	public void init() {
		//set backdrop and the color it will be
		backdrop = new GRect(getWidth(), getHeight());
		grassGreen = new Color(200, 255, 200);
		//initialize gamePlay object
		gamePlayer = new gamePlay();
		//init level
		level = 1;
	}
	
	public void run() {
		
		addBackground();
		gamePlayer.addPeople(level);
		
	}
	
	private void addBackground() {
		//add the background and associated settings
		backdrop.setFilled(true);
		backdrop.setFillColor(grassGreen);
		add(backdrop);
	}
	

	
	GRect backdrop;
	Color grassGreen;
	gamePlay gamePlayer;
	int level = 1;

}
