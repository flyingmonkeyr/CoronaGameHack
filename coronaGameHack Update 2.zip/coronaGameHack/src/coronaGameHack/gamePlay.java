package coronaGameHack;

public class gamePlay {

	public gamePlay() {
		// TODO Auto-generated constructor stub
		
	}
	
	public void addPeople(int level) {
		//initialize people 6 ft apart
		
	}

	
	
}
