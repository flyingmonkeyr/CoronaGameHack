package coronaGameHack;

public class levelValues {

	public levelValues() {
		// TODO Auto-generated constructor stub
		int level1 = 2;
	}

}
