package coronaGameHack;

//imports
import acm.graphics.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.*;

import acm.io.*;
import acm.program.*;
import java.lang.*;
import javax.swing.*;

public class person extends GCompound{

	public person() {
		// TODO Auto-generated constructor stub
		
		//initialize the shapes
		head = new GOval(5, 5);
		leftArm = new GRect(7, 2);
		rightArm = new GRect(7, 2);
				
	}
	
	GOval head;
	GRect leftArm;
	GRect rightArm;
}
