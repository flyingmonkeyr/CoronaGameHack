//imports

import acm.graphics.*;
import acm.io.*;
import acm.program.*;

public class gameInteraction extends GraphicsProgram{

	public gameInteraction() {
		// TODO Auto-generated constructor stub
	}

}
