public class Main {
    public static void main(String[] args) {

        BasicGameApp myGame;            //declare a variable called myGame that's of the type BasicGameApp]
        System.out.println("Starts the basicgame app - runs everything");
        myGame = new BasicGameApp();    //creates/builds a new instance of the game
        System.out.println("the game is declared");
        new Thread(myGame).run();       //creates a thread & starts up the code in the run( ) method of the game
        System.out.println("a method that tells the game to run");
    }

}
