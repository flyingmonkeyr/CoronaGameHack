//imports

import acm.graphics.*;
import java.awt.Graphics2D;
import acm.io.*;
import acm.program.*;
import java.awt.*;
import java.awt.Graphics2D;
import java.awt.image.BufferStrategy;
import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.io.*;
import javax.sound.sampled.*;
import java.awt.event.*;

public class BasicGameApp implements Runnable, KeyListener {

	public BasicGameApp() {
		// TODO Auto-generated constructor stub


	}



	public void init() {
		setUpGraphics();
		//set backdrop and the color it will be
		backdrop = new GRect(getWidth(), getHeight());
		grassGreen = new Color(200, 255, 200);
		//initialize gamePlay object
		gamePlayer = new gamePlay();
		//init level
		level = 1;
	}
	
	public void run() {
		
		addBackground();
		gamePlayer.addPeople(level);
		
	}

	public void setUpGraphics() {
		frame = new JFrame("Title of the windown");
		panel = (JPanel) frame.getContentPane();
		panel.setPreferredSize(new Dimension(WIDTH, HEIGHT));
		panel.setLayout(null);


		canvas = new Canvas();
		canvas.setBounds(0, 0, WIDTH, HEIGHT);
		canvas.setIgnoreRepaint(true);
		canvas.addKeyListener(this);
		panel.add(canvas);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setResizable(false);
		frame.setVisible(true);

		canvas.createBufferStrategy(2);
		bufferStrategy = canvas.getBufferStrategy();
		canvas.requestFocus();
	}

	public void render() {
		//System.out.println("returns the values");
		Graphics2D g = (Graphics2D) bufferStrategy.getDrawGraphics();
	}

	public void moveThings () {

	}

	public void checkIntersections () {
	}

	private void reset () {

	}

	public void pause ( int time){

		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {

		}

	}

	public void playSound (String name){

	}

	public void keyPressed (KeyEvent e) {
		//System.out.println("shows which keys are pressed");
		char key = e.getKeyChar();
	}
		private void addBackground() {
		//add the background and associated settings
		backdrop.setFilled(true);
		backdrop.setFillColor(grassGreen);
		add(backdrop);
	}
	

	
	GRect backdrop;
	Color grassGreen;
	gamePlay gamePlayer;
	int level = 1;

}
